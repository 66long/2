<script>
			L2Dwidget.init({pluginRootPath:"live2dw/",pluginJsPath:"lib/",pluginModelPath:"assets/",tagMode:!1,debug:!1,model:{scale:2,jsonPath:"live2dw/assets/asuna_33.model.json"},display:{position:"left",width:130,height:210,hOffset:40},mobile:{show:!1},log:!1})
		</script>